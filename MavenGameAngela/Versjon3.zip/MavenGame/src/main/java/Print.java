import com.googlecode.lanterna.SGR;
import com.googlecode.lanterna.TextColor;
import com.googlecode.lanterna.terminal.Terminal;

import java.io.IOException;

public class Print {

    public static void printInstructions() throws IOException, InterruptedException {
        Main.terminal.setForegroundColor(TextColor.ANSI.YELLOW);
        Main.terminal.setBackgroundColor(TextColor.ANSI.BLUE);
        Main.terminal.enableSGR(SGR.BOLD);
        Print.print(Main.terminal, "------Instructions-----", 5, 5);
        Main.terminal.setForegroundColor(TextColor.ANSI.MAGENTA);
        Main.terminal.setBackgroundColor(TextColor.ANSI.BLUE);
        Print.print(Main.terminal, "You are in a club, and you just want to dance...", 10, 10);
        Print.print(Main.terminal, "Unfortunately, others also want to dance... but with/on YOU!", 10, 20);
        Print.print(Main.terminal, "Your goal is to stay away from the SLEAZERS, for as long as possible", 10, 30);
        Print.print(Main.terminal, "Drink VODKA REDBULL('\u2605') for a temporary speed boost.", 10, 40);
        Thread.sleep(5000);
    }

    public static void printCredits() throws IOException, InterruptedException {
        Main.terminal.setForegroundColor(TextColor.ANSI.YELLOW);
        Main.terminal.setBackgroundColor(TextColor.ANSI.BLUE);
        Main.terminal.enableSGR(SGR.BOLD);
        Print.print(Main.terminal, "------Credits-----", 5, 5);
        Main.terminal.setForegroundColor(TextColor.ANSI.MAGENTA);
        Main.terminal.setBackgroundColor(TextColor.ANSI.BLUE);
        Print.print(Main.terminal, "Code, and awesome spirit: Angela", 10, 10);
        Print.print(Main.terminal, "Code, and awesome hand stands: Karoline", 10, 20);
        Print.print(Main.terminal, "Code, and awesome, sexy voice: Christian", 10, 30);
        Print.print(Main.terminal, "Code, and handsome looks: Mirdon", 10, 40);
        Thread.sleep(5000);

    }




    public static void print(Terminal terminal, String text, int x, int y) throws IOException {


        terminal.setCursorPosition(x, y);

        int stringLength = text.toCharArray().length;

        for (int i = 0; i < stringLength; i++) {

            terminal.putCharacter(text.charAt(i));


        }

    }
}
