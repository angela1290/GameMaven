import com.googlecode.lanterna.SGR;
import com.googlecode.lanterna.TextColor;
import com.googlecode.lanterna.input.KeyType;
import java.io.IOException;

public class PrintMenu {

    public static Character printMenu() throws IOException, InterruptedException {

        Main.terminal.setForegroundColor(TextColor.ANSI.YELLOW);
        Main.terminal.setBackgroundColor(TextColor.ANSI.BLUE);
        Main.terminal.enableSGR(SGR.BOLD);
        Print.print(Main.terminal, "------Club Sleazers-----", 5, 5);
        Main.terminal.setForegroundColor(TextColor.ANSI.MAGENTA);
        Main.terminal.setBackgroundColor(TextColor.ANSI.BLUE);
        Print.print(Main.terminal, "1 start new game", 10, 10);
        Print.print(Main.terminal, "2 instructions", 10, 20);
        Print.print(Main.terminal, "3 credits", 10, 30);
        Print.print(Main.terminal, "4 quit game", 10, 40);

        do {
            Thread.sleep(0); // might throw InterruptedException
            Main.keyStroke = Main.terminal.pollInput();

        } while (Main.keyStroke == null);

        KeyType type = Main.keyStroke.getKeyType();
        Character c = Main.keyStroke.getCharacter();

        return c;
    }
}
