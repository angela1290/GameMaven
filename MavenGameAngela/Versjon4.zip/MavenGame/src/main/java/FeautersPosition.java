public class FeautersPosition {

    int redBullX;
    int redBullY;

    public FeautersPosition(int redBullX, int redBullY) {
        this.redBullX = redBullX;
        this.redBullY = redBullY;
    }

    public int getRedBullX() {
        return redBullX;
    }

    public void setRedBullX(int redBullX) {
        this.redBullX = redBullX;
    }

    public int getRedBullY() {
        return redBullY;
    }

    public void setRedBullY(int redBullY) {
        this.redBullY = redBullY;
    }
}
